# COSEWIC-compilation

This code compiles data from the Pacific Salmon Explorer to facilitate rapid probable designations for COSEWIC's Marine Fish Subcommittee

For more information on data sources and methods, see Pacific Salmon Foundation, 2020 (https://salmonwatersheds.ca/library/lib_459/)
